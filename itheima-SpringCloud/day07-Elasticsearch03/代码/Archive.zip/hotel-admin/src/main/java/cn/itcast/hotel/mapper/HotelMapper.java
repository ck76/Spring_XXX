package cn.itcast.hotel.mapper;

import cn.itcast.hotel.pojo.Hotel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface HotelMapper extends BaseMapper<Hotel> {
}
